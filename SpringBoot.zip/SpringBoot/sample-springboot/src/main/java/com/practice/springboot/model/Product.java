package com.practice.springboot.model;

public class Product {
	
	private String productName;
	private int id;
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductId() {
		return id;
	}
	public void setProductId(int productId) {
		this.id = productId;
	}
	
}
