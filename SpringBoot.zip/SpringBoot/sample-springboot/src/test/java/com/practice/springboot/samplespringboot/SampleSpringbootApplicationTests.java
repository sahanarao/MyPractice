package com.practice.springboot.samplespringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

@SpringBootTest
class SampleSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
