
public class fibonacci {

	public static void main(String[] args) {
		int n = 8;
		if(n==1) {
			System.out.println("0");
		}
		else if(n==2) {
			System.out.println("1");
		}
		else{
			int init = 0,fib = 0, res =1;
			System.out.println(init);
			System.out.println(res);
			for(int i=1;i<n-1;i++) {							
				fib = init + res;
				System.out.println(fib);
				init = res;
				res = fib;				
			}

		}
	}
}
