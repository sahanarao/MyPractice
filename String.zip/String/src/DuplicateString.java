import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class DuplicateString {
	public static void main(String[] args) {
		String[] str = {"a","a","b","c","c","d","d","e","f","g","h","h","f","w","x"};
		Map<String,Integer> mp = new HashMap<String, Integer>();
		int count = 0;
		for(String string : str) {
			mp.put(string,mp.containsKey(string)?++count:0);
			count = 0;
		}

		System.out.println("Unique elements: ");
		for (Entry<String, Integer> entry : mp.entrySet())
			if(entry.getValue()<1) {
			System.out.println(entry.getKey());
			}
	} 
}
