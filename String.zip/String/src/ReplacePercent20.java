
public class ReplacePercent20 {
	public static void main(String[] args) {
		String str = "http://www.google.com/abcd%20/something%20";
		String str1 = null;
		if(str.contains("%20")) {
			str1= str.replace("%20", " ");
		}
		System.out.println(str1);
	}

}
