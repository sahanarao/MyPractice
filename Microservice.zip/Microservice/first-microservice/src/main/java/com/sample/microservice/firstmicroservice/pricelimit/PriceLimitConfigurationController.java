package com.sample.microservice.firstmicroservice.pricelimit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.microservice.firstmicroservice.model.PriceLimitConfiguration;

@RestController
public class PriceLimitConfigurationController {
	@Autowired
	PriceLimitConfiguration priceLimitConfig;
	
	@GetMapping("/pricelimits")
	public PriceLimitConfiguration getPriceLimits() {
		return new PriceLimitConfiguration(priceLimitConfig.getMinimum(), priceLimitConfig.getMaximum());
	}

}
