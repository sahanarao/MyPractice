package com.java.practice.SinglyLinkedList;

public class EmployeeNode {
	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	private EmployeeNode next;

	private Employee employee;
	
	public EmployeeNode(Employee employee) {
		super();
		this.employee = employee;
	}

	public EmployeeNode getNext() {
		return next;
	}
	
	public void setNext(EmployeeNode next) {
		this.next = next;
	}
	
	
	
	@Override
	public String toString() {
		return employee.toString();
	}
	
	

}
