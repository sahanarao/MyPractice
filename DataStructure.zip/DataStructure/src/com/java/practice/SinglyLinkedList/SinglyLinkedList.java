package com.java.practice.SinglyLinkedList;

public class SinglyLinkedList {

	public static void main(String[] args) {
		Employee sahanaRao = new Employee("Sahana","Rao",56);
		Employee hatiRam = new Employee("Hati","Ram",89);
		Employee sanjanaRai = new Employee("Sanjana","Rai",34);
		Employee sanchitaPai = new Employee("Sanchita","Pai",44);
		Employee mohanGarg = new Employee("Mohan","Garg",43);
		EmployeeLinkedList list = new EmployeeLinkedList();
		list.addToFront(sahanaRao);
		list.addToFront(sanjanaRai);
		list.addToFront(mohanGarg);
		list.addToFront(sanchitaPai);
		list.addToFront(hatiRam);
		list.printList();
		System.out.println(list.getSize());
		list.removeNode();
		System.out.println("After removal");
		list.printList();
		System.out.println(list.getSize());
	}
}
