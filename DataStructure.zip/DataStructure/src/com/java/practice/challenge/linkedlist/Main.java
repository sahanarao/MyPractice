package com.java.practice.challenge.linkedlist;

public class Main {

	public static void main(String[] args) {
	    Employee sahanaRao = new Employee(56);
		Employee hatiRam = new Employee(89);
		Employee sanjanaRai = new Employee(34);
		Employee sanchitaPai = new Employee(4);
		Employee mohanGarg = new Employee(3);
		EmployeeLinkedList list = new EmployeeLinkedList();
		list.addToFront(sahanaRao);
		list.addToFront(sanjanaRai);
		list.addToFront(mohanGarg);
		list.addToFront(sanchitaPai);
		list.addToFront(hatiRam);
		list.printList();
		System.out.println(list.getSize());
	}
}
