package com.java.practice.challenge.linkedlist;

public class EmployeeLinkedList {
	private EmployeeNode head;
	private int size;

	public void addToFront(Employee employee) {
		EmployeeNode node = new EmployeeNode(employee);

		if(head == null) {
			head = node;
		}
		else {	
			EmployeeNode current = head.getNext();
			EmployeeNode previous = head;
			if(node.getEmployee().getEmpId()<=head.getEmployee().getEmpId()) {
				node.setNext(head);
				head = node;
			}
			else {
				while(current!=null && node.getEmployee().getEmpId()>=current.getEmployee().getEmpId()) {
					previous = current;
					current = current.getNext();
				}
				node.setNext(current);
				previous.setNext(node);
			}
		}
		size++;
	}
	
	public int getSize() {
		return size;
	}
	
	public void printList() {
		EmployeeNode current = head;
		while(current!=null) {
			System.out.println(current);
			current = current.getNext();
		}

	}
	
}
