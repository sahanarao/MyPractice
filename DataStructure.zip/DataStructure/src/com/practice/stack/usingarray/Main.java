package com.practice.stack.usingarray;

import com.java.practice.SinglyLinkedList.Employee;

public class Main {
	
	public static void main(String[] args) {
		Employee sahanaRao = new Employee("Sahana","Rao",56);
		Employee hatiRam = new Employee("Hati","Ram",89);
		Employee sanjanaRai = new Employee("Sanjana","Rai",34);
		Employee sanchitaPai = new Employee("Sanchita","Pai",44);
		Employee mohanGarg = new Employee("Mohan","Garg",43);		
		ArrayStack stack = new ArrayStack(10);
		stack.push(mohanGarg);
		stack.push(sanchitaPai);
		stack.push(sanjanaRai);
		stack.push(hatiRam);
		stack.push(sahanaRao);
		stack.printStack();
		System.out.println(stack.peek());		
	}

}
