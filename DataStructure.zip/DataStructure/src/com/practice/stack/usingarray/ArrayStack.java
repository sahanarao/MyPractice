package com.practice.stack.usingarray;

import java.util.NoSuchElementException;

import com.java.practice.SinglyLinkedList.Employee;

public class ArrayStack {
	
	private Employee[] stackArray;
	
	private int top;
		
	public ArrayStack(int capacity) {		
		super();
		stackArray = new Employee[capacity]; 
	}

	public void push(Employee employee) {
		if(top>=stackArray.length) {
			Employee[] newArray = new Employee[2*stackArray.length];
			System.arraycopy(stackArray, 0, newArray, 0, stackArray.length);
			newArray = stackArray;
		}
		stackArray[top]=employee;
		top++;	
	}
	
	public Employee pop() {
		if(stackArray.length==0) {
			throw new NoSuchElementException();
		}
		else {
			Employee employee = stackArray[top];
			stackArray[top] = null;
			top --;
			return employee;
		}
	}
	
	public Employee peek() {
		if(stackArray.length==0) {
			throw new NoSuchElementException();
		}
		else {
			Employee employee = stackArray[top-1];
			return employee;
		}
	}
	
	public void printStack() {
		for(int i=0;i<stackArray.length;i++) {			
			System.out.println(stackArray[i]);
		}
	}
	

}
