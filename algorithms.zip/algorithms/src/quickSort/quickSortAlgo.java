package quickSort;

public class quickSortAlgo {
	
	public static void main(String[] args) {
		int[] arr= {22,-1,45,67,4,58,23};
		quicksort(arr,0,arr.length);
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
	}

	public static void quicksort(int[] arr,int start, int end) {
		if(end - start < 2) {
			return;
		}
		int pivotindex = partition(arr, start, end);
		quicksort(arr, start, pivotindex);
		quicksort(arr, pivotindex +1,end);
				
	}
	public static int partition(int[] arr, int start, int end) {
		int pivotindex = arr[start];
		int i = start;
		int j = end;
		while(i<j) {
			
			while(i<j && arr[--j]>=pivotindex);
			if(i<j) {
				arr[i]=arr[j];
			}
			
			while(i<j && arr[++i]<=pivotindex);
			if(i<j) {
				arr[j]=arr[i];
			}
			
			
		}
		arr[j] = pivotindex;
		return j;
	}
}
